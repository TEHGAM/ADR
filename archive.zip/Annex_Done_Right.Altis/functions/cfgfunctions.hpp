class QS
{
	tag = "QS";
	class functions
	{
		file = "functions";
		class AOdelete {};
		class AOenemy {};
		class AOminefield {};
		class deleteUnits {};
		class garrisonFortEAST {};
		class garrisonFortIND {};
		class garrisonFortFIA {};
		class setSkill1 {};
		class setSkill2 {};
		class setSkill3 {};
		class setSkill4 {};
		class PTenemyEAST {};
		class SMenemyEAST {};
		class SMenemyEASTintel {};
		class SMenemyIND {};
		class SMenemyFIA {};
		class SMdelete {};
		class SMhintFAIL {};
		class SMhintSUCCESS {};
		class rewardPlusHintJet {};
		class addAction {};
		class addActionGetIntel {};
		class addActionSurrender {};
		class removeAction {};
		class removeAction0 {};
		class removeAction1 {};
		class serverMapTP {};
	};
};
