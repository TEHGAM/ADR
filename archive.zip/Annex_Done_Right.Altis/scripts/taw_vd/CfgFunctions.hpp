class TAWVD
{
  tag = "TAWVD";
  class TAW_VD
  {
    file = "scripts\taw_vd";
    class onSliderChange {};
    class onTerrainChange {};
    class updateViewDistance {};
    class openTAWVD {};
    class trackViewDistance {};
    class tawvdInit {postInit = 1;};
  };
};