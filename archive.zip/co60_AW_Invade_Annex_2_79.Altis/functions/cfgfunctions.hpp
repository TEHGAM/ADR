class QS
{
	tag = "QS";
	class functions
	{
		file = "functions";
		class actionClearInventory {};
		class addAction {};
		class addActionGetIntel {};
		class addActionSurrender {};
		class AOdelete {};
		class AOenemy {};
		class AOminefield {};
		class conditionClearInventory {};
		class conditionUH80TurretActionLock {};
		class conditionUH80TurretActionUnlock {};
		class deleteUnits {};
		class enemyCAS {};
		class garrisonFortEAST {};
		class garrisonFortFIA {};
		class garrisonFortIND {};
		class loadInventory {};
		class PTenemyEAST {};
		class removeAction {};
		class removeAction0 {};
		class removeAction1 {};
		class respawnPilot {};
		class rewardPlusHintJet {};
		class saveInventory {};
		class serverMapTP {};
		class setSkill1 {};
		class setSkill2 {};
		class setSkill3 {};
		class setSkill4 {};
		class SMdelete {};
		class SMenemyEAST {};
		class SMenemyEASTintel {};
		class SMenemyFIA {};
		class SMenemyIND {};
		class SMhintFAIL {};
		class SMhintSUCCESS {};
		class uh80Turret {};
		class uh80TurretActions {};
		class vMonitor {};
		class vSetup02 {};
	};
};
