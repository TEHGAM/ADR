#### **Вооружение самолетов**
***
**Пушки:**
```
Twin_Cannon_20mm	 			300Rnd_20mm_shells					//A-143 Buzzard
Gatling_30mm_Plane_CAS_01_F		1000Rnd_Gatling_30mm_Plane_CAS_01_F	//A-164 Wipeout
Cannon_30mm_Plane_CAS_02_F		500Rnd_Cannon_30mm_Plane_CAS_02_F	//To-199 Neophron
```
**Ракеты воздух-поверхность:**
```
missiles_SCALPEL				2Rnd_LG_scalpel			//A-143 Buzzard
Missile_AGM_02_Plane_CAS_01_F	6Rnd_Missile_AGM_02_F	//A-164 Wipeout
Missile_AGM_01_Plane_CAS_02_F	4Rnd_Missile_AGM_01_F	//To-199 Neophron
```
**Ракеты воздух-воздух:**
```
missiles_Zephyr					4Rnd_GAA_missiles		//A-143 Buzzard
missiles_ASRAAM					2Rnd_AAA_missiles		//A-143 Buzzard
Missile_AA_04_Plane_CAS_01_F	2Rnd_Missile_AA_04_F	//A-164 Wipeout
Missile_AA_03_Plane_CAS_02_F	2Rnd_Missile_AA_03_F	//To-199 Neophron
```
**Неуправляемые реактивные снаряды:**
```
Rocket_04_HE_Plane_CAS_01_F		7Rnd_Rocket_04_HE_F		//A-164 Wipeout Осколочно-фугасная бч	
Rocket_04_AP_Plane_CAS_01_F		7Rnd_Rocket_04_AP_F		//A-164 Wipeout Кумулятивно-осколочная бч

Rocket_03_HE_Plane_CAS_02_F		20Rnd_Rocket_03_HE_F	//To-199 Neophron Осколочно-фугасная бч	
Rocket_03_AP_Plane_CAS_02_F		20Rnd_Rocket_03_AP_F	//To-199 Neophron Кумулятивно-осколочная бч
```
**Бомбы:**
```
GBU12BombLauncher				2Rnd_GBU12_LGB_MI10		//A-143 Buzzard
Bomb_04_Plane_CAS_01_F			4Rnd_Bomb_04_F			//A-164 Wipeout
Bomb_03_Plane_CAS_02_F			2Rnd_Bomb_03_F			//To-199 Neophron
```
***
#### **Вооружение вертолетов**
***
**Пушки:**
```
M134_minigun		5000Rnd_762x51_Yellow_Belt				//WY-55 Hellcat
LMG_Minigun_heli	2000Rnd_65x39_Belt_Tracer_Green_Splash	//PO-30 Orca
gatling_30mm		250Rnd_30mm_APDS_shells					//Mi-48 Kajman Бронебойные
					250Rnd_30mm_HE_shells					//Mi-48 Kajman Осколочно-фугасные
gatling_20mm		1000Rnd_20mm_shells						//AH-99 Blackfoot
M134_minigun		5000Rnd_762x51_Belt 					//AH-9 Pawnee
```
**Бортовые пулеметы**
```
LMG_Minigun_Transport 	2000Rnd_65x39_Belt_Tracer_Red		//CH-67 Huron
LMG_Minigun_Transport2	2000Rnd_65x39_Belt_Tracer_Red		//CH-67 Huron

LMG_Minigun_Transport	2000Rnd_65x39_Belt_Tracer_Red		//UH-80 Ghost Hawk
LMG_Minigun_Transport2	2000Rnd_65x39_Belt_Tracer_Red		//UH-80 Ghost Hawk
```
**Ракеты водух-воздух**
```
missiles_ASRAAM			4Rnd_AAA_missiles					//AH-99 Blackfoot
```
**Ракеты воздух поверхность**
```
missiles_DAGR			24Rnd_PG_missiles					//AH-99 Blackfoot
						12Rnd_PG_missiles					//PO-30 Orca 
missiles_SCALPEL		8Rnd_LG_scalpel						//Mi-48 Kajman
```
**Неуправляемые реактивные снаряды:**
```
missiles_DAR			24Rnd_missiles						//AH-9 Pawnee, WY-55 Hellcat
						12Rnd_missiles 						//PO-30 Orca (Black & White)
rockets_Skyfire			38Rnd_80mm_rockets					//Mi-48 Kajman
```
***
#### **Вооружения танков**
***
**Основной калибр**
```
cannon_120mm_long	28Rnd_120mm_APFSDS_shells_Tracer_Yellow	//MBT-52 Kuma Бронебойный подкалиберный трассирующий
					14Rnd_120mm_HE_shells_Tracer_Yellow		//MBT-52 Kuma Осколочно-фугасный трассирующий
cannon_120mm 		32Rnd_120mm_APFSDS_shells_Tracer_Red	//M2A1 Slammer Бронебойный подкалиберный трассирующий
					16Rnd_120mm_HE_shells_Tracer_Red		//M2A1 Slammer Осколочно-фугасный трассирующий
cannon_105mm		40Rnd_105mm_APFSDS_T_Red				//M2A4 Slammer UP Бронебойный подкалиберный трассирующий
					20Rnd_105mm_HEAT_MP_T_Red				//M2A4 Slammer UP Кумулятивный трассирующий снаряд многоцелевого назначения 
cannon_125mm		24Rnd_125mm_APFSDS_T_Green				//T-100 Varsuk Бронебойный подкалиберный трассирующий
					12Rnd_125mm_HE_T_Green					//T-100 Varsuk Осколочно-фугасный трассирующий
					12Rnd_125mm_HEAT_T_Green				//T-100 Varsuk Кумулятивно-трассирующий
```
**Пулемет стрелка**
```
LMG_coax			2000Rnd_762x51_Belt_Yellow				//MBT-52 Kuma
					2000Rnd_762x51_Belt_Green				//T-100 Varsuk
LMG_M200			2000Rnd_65x39_belt 						//M2A1 Slammer, M2A4 Slammer UP
```
**Командирская турель**
```
HMG_127_APC			500Rnd_127x99_mag_Tracer_Yellow			//MBT-52 Kuma
HMG_127_MBT			500Rnd_127x99_mag_Tracer_Red			//M2A4 Slammer UP
HMG_NSVT			450Rnd_127x108_Ball						//T-100 Varsuk
```
***
#### **Вооружение БТР\БМП**
***
**Основной калибр**
```
autocannon_30mm			140Rnd_30mm_MP_shells_Tracer_Yellow		//FV-720 Mora ОФ
						60Rnd_30mm_APFSDS_shells_Tracer_Yellow	//FV-720 Mora БП
autocannon_30mm_CTWS	140Rnd_30mm_MP_shells_Tracer_Yellow		//AFV-4 Gorgon ОФ
						60Rnd_30mm_APFSDS_shells_Tracer_Yellow	//AFV-4 Gorgon БП
autocannon_40mm_CTWS	60Rnd_40mm_GPR_Tracer_Red_shells		//AMV-7 Marshall ОФ
						40Rnd_40mm_APFSDS_Tracer_Red_shells		//AMV-7 Marshall БП
GMG_40mm				96Rnd_40mm_G_belt						//IFV-6c Panther, MSE-3 Marid
autocannon_30mm_CTWS	140Rnd_30mm_MP_shells_Tracer_Green		//BTR-K Kamysh ОФ
						60Rnd_30mm_APFSDS_shells_Tracer_Green	//BTR-K Kamysh БП
```
**Пулемет стрелка**
```
LMG_M200				1000Rnd_65x39_Belt_Yellow				//AFV-4 Gorgon
						2000Rnd_65x39_belt 						//AMV-7 Marshall
						1000Rnd_65x39_Belt_Green 				//BTR-K Kamysh
LMG_coax				1000Rnd_762x51_Belt_Yellow				//FV-720 Mora
HMG_127_APC				500Rnd_127x99_mag_Tracer_Red			//IFV-6c Panther
						500Rnd_127x99_mag_Tracer_Green 			//MSE-3 Marid
LMG_RCWS				2000Rnd_65x39_belt 						//CRV-6e Bobcat
```
**Противотанковая управляемая ракета**
```
missiles_titan			2Rnd_GAT_missiles						//AFV-4 Gorgon, BTR-K Kamysh
```
***
#### **Вооружение самоходных зенитных установок**
***
**Ствольное вооружение**
```
autocannon_35mm		680Rnd_35mm_AA_shells_Tracer_Red		//IFV-6a Cheetah
					680Rnd_35mm_AA_shells_Tracer_Green		//ZSU-39 Tigris
```
**Ракеты земля-воздух**
```
missiles_titan		4Rnd_Titan_long_missiles				//IFV-6a Cheetah , ZSU-39 Tigris
```
***
#### **Вооружение самоходных артиллерийских установок**
***
**Основное орудие**
```
mortar_155mm_AMOS	32Rnd_155mm_Mo_shells		//Осколочно-фугасный снаряд
					2Rnd_155mm_Mo_guided		//Управляемый артиллерийский снаряд
					6Rnd_155mm_Mo_mine			//Противопехотные мины
					2Rnd_155mm_Mo_Cluster		//Кассетный снаряд
					6Rnd_155mm_Mo_smoke			//Дымовой снаряд
					2Rnd_155mm_Mo_LG			//Снаряд с лазерным наведением
					6Rnd_155mm_Mo_AT_mine		//Противотанковые мины
```
**Командирская турель**
```
GMG_40mm			96Rnd_40mm_G_belt				//M4 Scorcher, 2S9 Sochor
HMG_127_APC			500Rnd_127x99_mag_Tracer_Red	//M4 Scorcher
					500Rnd_127x99_mag_Tracer_Green	//2S9 Sochor
```
**Реактивная артиллерия**
```
rockets_230mm_GAT	12Rnd_230mm_rockets			//M5 Sandstorm MLRS
```
